-- Cria uma tabela de exemplo no banco de dados escola
CREATE TABLE alunos (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(100),
    idade INT
);
